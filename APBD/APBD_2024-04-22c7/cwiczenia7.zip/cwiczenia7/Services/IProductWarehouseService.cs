﻿using cwiczenia7.Models;

namespace cwiczenia7.Services
{
    public interface IProductWarehouseService
    {
        int PostWareProd(ProductWarehouse warehouse);
    }
}
