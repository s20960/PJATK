﻿using cwiczenia7.Models;

namespace cwiczenia7.Repositories
{
    public interface IProductWarehouseRepository
    {
        int Create(ProductWarehouse warehouse);
    }
}
