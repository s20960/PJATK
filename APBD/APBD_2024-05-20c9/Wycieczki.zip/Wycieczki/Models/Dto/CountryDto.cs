﻿namespace Wycieczki.Models.Dto
{
    public class CountryDto
    {
        public string Name { get; set; } = null!;
    }
}
