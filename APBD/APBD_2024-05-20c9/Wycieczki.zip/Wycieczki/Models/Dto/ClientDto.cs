﻿namespace Wycieczki.Models.Dto
{
    public class ClientDto
    {
        public string FirstName { get; set; } = null!;
        public string LastName { get; set; } = null!;
    }
}
