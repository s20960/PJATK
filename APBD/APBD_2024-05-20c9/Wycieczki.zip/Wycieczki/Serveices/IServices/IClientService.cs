﻿namespace Wycieczki.Serveices.IServices
{
    public interface IClientService
    {
        public Task DeleteClientAsync(int id);
    }
}
