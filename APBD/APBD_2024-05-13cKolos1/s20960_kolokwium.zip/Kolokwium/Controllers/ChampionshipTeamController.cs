﻿using Kolokwium.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Kolokwium.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChampionshipTeamController : ControllerBase
    {
        public readonly IChampionshipTeamService _championshipTeamService;

        public ChampionshipTeamController(IChampionshipTeamService championshipTeamService)
        {
            _championshipTeamService = championshipTeamService;
        }

        [HttpGet]
        public IActionResult Get(int IdChampionship) 
        {
            _championshipTeamService.GetTeamsByChampionShip(IdChampionship);
            return Ok();
        }
    }
}
