﻿namespace Kolokwium.Service
{
    public interface IPlayerTeamService
    {
    }
}
