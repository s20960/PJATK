﻿using Kolokwium.Models.Dto;

namespace Kolokwium.Service
{
    public interface IChampionshipTeamService
    {
        public IEnumerable<TeamForChampionShipDto> GetTeamsByChampionShip(int championshipId);
    }
}
