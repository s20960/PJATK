﻿using Kolokwium.Models.Dto;
using Kolokwium.Repository;

namespace Kolokwium.Service
{
    public class ChampionshipTeamService : IChampionshipTeamService
    {
        private readonly IChampionshipTeamRepository _championshipTeamRepository;

        public ChampionshipTeamService(IChampionshipTeamRepository championshipTeamRepository)
        {
            _championshipTeamRepository = championshipTeamRepository;
        }

        public IEnumerable<TeamForChampionShipDto> GetTeamsByChampionShip(int championshipId)
        {
            var teams = _championshipTeamRepository.ReadTeamsByChampionShip(championshipId); 
            return teams;
        }

    }
}
