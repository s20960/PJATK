﻿namespace Kolokwium.Service
{
    public class PlayerTeamService : IPlayerTeamService
    {
    }
}
