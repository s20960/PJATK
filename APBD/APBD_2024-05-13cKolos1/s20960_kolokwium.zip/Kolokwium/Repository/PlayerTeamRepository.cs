﻿using Kolokwium.Models.Dto;
using System.Data.SqlClient;

namespace Kolokwium.Repository
{
    public class PlayerTeamRepository
    {
        public readonly IConfiguration _configuration;

        public PlayerTeamRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public /*await*/ int AddPlayer(int idPlayer, int idTeam, PlayerForTeamDto playerForTeamDto)
        {
            using var con = new SqlConnection(_configuration["ConnectionStrings:DefaultConnection"]);
            con.Open();

            using var cmd = new SqlCommand();
            cmd.Connection = con;

            cmd.CommandText = "INSERT INTO Player_Team Values(@IdPlayer, @IdTeam, @NumOnShirt, @Comment)";

            cmd.Parameters.AddWithValue("@IdPlayer", idPlayer);
            cmd.Parameters.AddWithValue("@IdTeam", idTeam);
            cmd.Parameters.AddWithValue("@NumOnShirt", playerForTeamDto.NumOnShirt);
            cmd.Parameters.AddWithValue("@Comment", playerForTeamDto.Comment);


            var affectedCount = cmd.ExecuteNonQuery();
            return affectedCount;
        }
    }
}
