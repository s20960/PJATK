﻿using Kolokwium.Models;
using Kolokwium.Models.Dto;
using System.Data.SqlClient;
using System.Xml.Linq;

namespace Kolokwium.Repository
{
    public class ChampionshipTeamRepository : IChampionshipTeamRepository
    {
        public readonly IConfiguration _configuration;

        public ChampionshipTeamRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public /*await*/ IEnumerable<TeamForChampionShipDto> ReadTeamsByChampionShip(int IdChampionship)
        {
            using var con = new SqlConnection(_configuration["ConnectionStrings:DefaultConnection"]);
            con.Open();

            using var cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText =   "SELECT t.IdTeam, t.TeamName, ct.Score " +
                                "FROM Team t " +
                                "INNER JOIN Championship_Team ct on t.IdTeam = ct.IdTeam" +
                                "INNER JOIN Championship c on ct.IdChampionship = c.IdChampionship" +
                                "WHERE c.IdChampionship = @IdChampionship";

            cmd.Parameters.AddWithValue("IdChampionship", IdChampionship);

            var dr = cmd.ExecuteReader();
            var teams = new List<TeamForChampionShipDto>();
            while (dr.Read())
            {
                var team = new TeamForChampionShipDto
                {
                    IdTeam = (int)dr["IdTeam"],
                    TeamName = dr["TeamName"].ToString(),
                    Score = (int)dr["Score"]
                };
                teams.Add(team);
            }

            return teams;
        }
    }
}
