﻿using Kolokwium.Models.Dto;

namespace Kolokwium.Repository
{
    public interface IChampionshipTeamRepository
    {
        public IEnumerable<TeamForChampionShipDto> ReadTeamsByChampionShip(int IdChampionship);
    }
}
