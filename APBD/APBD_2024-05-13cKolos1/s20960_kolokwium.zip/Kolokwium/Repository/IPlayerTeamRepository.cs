﻿namespace Kolokwium.Repository
{
    public interface IPlayerTeamRepository
    {
    }
}
