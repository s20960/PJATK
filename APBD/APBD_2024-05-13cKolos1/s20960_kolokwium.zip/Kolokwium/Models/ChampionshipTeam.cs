﻿using System.ComponentModel.DataAnnotations;

namespace Kolokwium.Models
{
    public class ChampionshipTeam
    {
        public int IdChampionshipTeam { get; set; }

        [Required]
        public int IdTeam { get; set; }

        [Required]
        public int IdChampionship { get; set; }

        [Required]
        public int Score { get; set; }
    }
}
