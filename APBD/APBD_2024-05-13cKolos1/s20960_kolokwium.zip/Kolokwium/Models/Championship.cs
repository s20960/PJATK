﻿using System.ComponentModel.DataAnnotations;

namespace Kolokwium.Models
{
    public class Championship
    {
        public int IdChampionship { get; set; }

        [Required]
        public string OfficialName { get; set; }

        [Required]
        public int Year { get; set; }
    }
}
