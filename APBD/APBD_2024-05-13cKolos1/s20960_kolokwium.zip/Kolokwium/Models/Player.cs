﻿using System.ComponentModel.DataAnnotations;

namespace Kolokwium.Models
{
    public class Player
    {
        public int IdPlayer { get; set; }

        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        [Required]
        public DateTime DateOfBirth { get; set; }
    }
}
