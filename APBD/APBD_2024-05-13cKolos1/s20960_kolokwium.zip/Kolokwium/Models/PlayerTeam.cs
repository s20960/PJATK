﻿using System.ComponentModel.DataAnnotations;

namespace Kolokwium.Models
{
    public class PlayerTeam
    {
        public int IdPlayerTeam { get; set; }

        [Required]
        public int IdPlayer { get; set; }

        [Required]
        public int IdTeam { get; set; }

        [Required]
        public int NumOnShirt { get; set; }
        public string? Comment { get; set; }
    }
}
