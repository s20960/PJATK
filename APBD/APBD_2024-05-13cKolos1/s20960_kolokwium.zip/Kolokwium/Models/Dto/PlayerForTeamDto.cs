﻿using System.ComponentModel.DataAnnotations;

namespace Kolokwium.Models.Dto
{
    public class PlayerForTeamDto
    {
        [Required]
        public int NumOnShirt { get; set; }
        public string? Comment { get; set; }
    }
}
