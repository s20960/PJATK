﻿using System.ComponentModel.DataAnnotations;

namespace Kolokwium.Models.Dto
{
    public class TeamForChampionShipDto
    {
        public int IdTeam { get; set; }

        [Required]
        public string TeamName { get; set; }

        [Required]
        public int Score { get; set; }
    }
}
