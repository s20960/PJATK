﻿using System.ComponentModel.DataAnnotations;

namespace Kolokwium.Models
{
    public class Team
    {
        public int IdTeam { get; set; }

        [Required]
        public string TeamName { get; set; }

        [Required]
        public int MaxAge { get; set; }
    }
}
